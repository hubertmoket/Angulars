import {Component, OnInit} from '@angular/core';
import {FirstService} from '../services/first.service';

@Component({
  selector: 'app-equipes',
  templateUrl: './equipes.component.html',
  styleUrls: ['./equipes.component.css']
})
export class EquipesComponent implements OnInit {

  private equipe: string = '';
  private nbreVote = 0;

  constructor(private olivierService: FirstService) {
    this.olivierService.methodeDuService();
  }

  ngOnInit() {
  }

  public recuperationVote(o) {
    if (o.vote > this.nbreVote) {
      this.nbreVote = o.vote;
      this.equipe = o.nom;
    }
  }

}
