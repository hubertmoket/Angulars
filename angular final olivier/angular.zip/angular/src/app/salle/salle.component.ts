import {Component, OnInit} from '@angular/core';
import {SalleService} from '../services/salle.service';
import {Salle} from '../model/salle';

@Component({
  selector: 'app-salle',
  templateUrl: './salle.component.html',
  styleUrls: ['./salle.component.css']
})
export class SalleComponent implements OnInit {

  salles: Salle[] = [];

  constructor(private salleService: SalleService) {
  }

  ngOnInit() {
    this.list();
  }

  private list() {
    this.salleService.findAll().subscribe(result => {
      console.log(result);
      this.salles = result;
    }, error1 => {
      console.log('pas bien');
    });
  }

  public delete(nom: string) {
    this.salleService.delete(nom).subscribe(result => {
      this.list();
    });
  }

}
