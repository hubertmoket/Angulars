import {Component, OnInit} from '@angular/core';
import {Salle} from '../model/salle';
import {SalleService} from '../services/salle.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-salle-edit',
  templateUrl: './salle-edit.component.html',
  styleUrls: ['./salle-edit.component.css']
})
export class SalleEditComponent implements OnInit {

  private salle: Salle = new Salle();

  constructor(private salleService: SalleService, private router: Router) {
  }

  ngOnInit() {
  }

  public save() {
    this.salleService.insert(this.salle).subscribe(result => {
      this.router.navigate(['/salle']);
    });
  }

}
