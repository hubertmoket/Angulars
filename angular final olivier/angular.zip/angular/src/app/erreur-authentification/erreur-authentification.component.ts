import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-erreur-authentification',
  templateUrl: './erreur-authentification.component.html',
  styleUrls: ['./erreur-authentification.component.css']
})
export class ErreurAuthentificationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
