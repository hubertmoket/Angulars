import {Component, OnInit} from '@angular/core';
import {Client} from '../model/client';

@Component({
  selector: 'app-clients',
  templateUrl: './clients.component.html',
  styleUrls: ['./clients.component.css']
})
export class ClientsComponent implements OnInit {

  private filtre = '';

  clients: Client[] = [new Client('azerty', 'fghj', 1000),
    new Client('toto', 'tutu', 20000)];

  constructor() {
  }

  ngOnInit() {
  }

  public push(client: Client) {
    this.clients.push(client);
  }

  public listeClient() {
    return this.clients.filter(client => {
      return client.prenom.indexOf(this.filtre) !== -1 ||
        client.nom.indexOf(this.filtre) !== -1;
    });
  }
}
