import {Injectable} from '@angular/core';

@Injectable()
export class FirstService {

  constructor() {
    console.log('construction du service first');
  }

  public methodeDuService() {
    console.log('methode du service first');
  }
}
