import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Observable} from 'rxjs';
import {Salle} from '../model/salle';

@Injectable({
  providedIn: 'root'
})
export class SalleService {

  private url: string = 'http://localhost:8080/demo/rest/salle';
  private headers: HttpHeaders;
  private options: object;

  constructor(private http: HttpClient) {
  }

  private authentication() {
    this.headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': 'Basic ' + sessionStorage.getItem('user')
    });
    this.options = {headers: this.headers};
  }

  public findAll(): Observable<any> {
    this.authentication();
    return this.http.get(this.url, this.options);
  }

  public delete(nom: string): Observable<any> {
    this.authentication();
    return this.http.delete(`${this.url}/${nom}`, this.options);
  }

  public insert(salle: Salle): Observable<any> {
    this.authentication();
    const o: object = {
      nom: salle.nom
    };
    return this.http.post(this.url, o, this.options);
  }
}
