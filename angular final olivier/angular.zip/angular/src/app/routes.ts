import {Route, Routes} from '@angular/router';
import {EquipesComponent} from './equipes/equipes.component';
import {ClientsComponent} from './clients/clients.component';
import {ParamComponent} from './param/param.component';
import {CrudClientMemoireComponent} from './crud-client-memoire/crud-client-memoire.component';
import {CrudClientEditComponent} from './crud-client-edit/crud-client-edit.component';
import {SalleComponent} from './salle/salle.component';
import {SalleEditComponent} from './salle-edit/salle-edit.component';
import {LoginComponent} from './login/login.component';
import {HomeComponent} from './home/home.component';
import {AuthenticationService} from './services/authentication.service';
import {ErreurAuthentificationComponent} from './erreur-authentification/erreur-authentification.component';

export const routes: Routes = [{path: 'equipes', component: EquipesComponent}, {
  path: 'clients', component: ClientsComponent
}, {path: 'param/:nom', component: ParamComponent},
  {path: 'crudClient', component: CrudClientMemoireComponent},
  {path: 'crudEditClient', component: CrudClientEditComponent},
  {path: 'crudEditClient/:index', component: CrudClientEditComponent},
  {path: 'salle', component: SalleComponent, canActivate: [AuthenticationService]},
  {path: 'salle/add', component: SalleEditComponent},
  {path: 'login', component: LoginComponent},
  {path: 'home', component: HomeComponent},
  {path: 'error/login', component: ErreurAuthentificationComponent},
  {path: '', redirectTo: '/home', pathMatch: 'full'}
];
