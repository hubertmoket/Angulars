import {Pipe, PipeTransform} from '@angular/core';

@Pipe({
  name: 'perso'
})
export class PersoPipe implements PipeTransform {

  transform(value: any, ...args: any[]): any {
    console.log(args);
    if (value > 1000000) {
      return '****';
    }
    return value;
  }

}
