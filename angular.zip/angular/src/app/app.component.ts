import {Component} from '@angular/core';
import {Personne} from './model/personne';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  public methode(param) {
    console.log(param);
  }

}
