import {Route, Routes} from '@angular/router';
import {EquipesComponent} from './equipes/equipes.component';
import {ClientsComponent} from './clients/clients.component';
import {ParamComponent} from './param/param.component';
import {CrudClientMemoireComponent} from './crud-client-memoire/crud-client-memoire.component';
import {CrudClientEditComponent} from './crud-client-edit/crud-client-edit.component';

export const routes: Routes = [{path: 'equipes', component: EquipesComponent}, {
  path: 'clients', component: ClientsComponent
}, {path: 'param/:nom', component: ParamComponent},
  {path: 'crudClient', component: CrudClientMemoireComponent},
  {path: 'crudEditClient', component: CrudClientEditComponent},
  {path: 'crudEditClient/:index', component: CrudClientEditComponent}
];
