import { PersoPipe } from './perso.pipe';

describe('PersoPipe', () => {
  it('create an instance', () => {
    const pipe = new PersoPipe();
    expect(pipe).toBeTruthy();
  });
});
