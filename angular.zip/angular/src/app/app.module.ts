import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';

import {AppComponent} from './app.component';
import {FormsModule} from '@angular/forms';
import {CouleurComponent} from './couleur/couleur.component';
import {ClientComponent} from './client/client.component';
import {CacherComponent} from './cacher/cacher.component';
import {AscBoldComponent} from './asc-bold/asc-bold.component';
import {AscBoldElementComponent} from './asc-bold-element/asc-bold-element.component';
import {AscToolTipsComponent} from './asc-tool-tips/asc-tool-tips.component';
import {SortieComponent} from './sortie/sortie.component';
import {EquipeComponent} from './equipe/equipe.component';
import {EquipesComponent} from './equipes/equipes.component';
import {TestDirective} from './test.directive';
import {ClientsComponent} from './clients/clients.component';
import {RouterModule} from '@angular/router';
import {routes} from './routes';
import { ParamComponent } from './param/param.component';
import { PersoPipe } from './pipe/perso.pipe';
import {FirstService} from './services/first.service';
import { CrudClientMemoireComponent } from './crud-client-memoire/crud-client-memoire.component';
import { CrudClientEditComponent } from './crud-client-edit/crud-client-edit.component';

@NgModule({
  declarations: [
    AppComponent,
    CouleurComponent,
    ClientComponent, ClientsComponent,
    CacherComponent,
    AscBoldComponent,
    AscBoldElementComponent,
    AscToolTipsComponent,
    SortieComponent,
    EquipeComponent,
    EquipesComponent,
    TestDirective,
    ParamComponent,
    PersoPipe,
    CrudClientMemoireComponent,
    CrudClientEditComponent
  ],
  imports: [
    BrowserModule, FormsModule, RouterModule.forRoot(routes)
  ],
  providers: [FirstService],
  bootstrap: [AppComponent]
})
export class AppModule {
}
