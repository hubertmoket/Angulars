import {Injectable} from '@angular/core';
import {Client} from '../model/client';

@Injectable({
  providedIn: 'root'
})
export class ClientService {

  private _clients: Client[] = [new Client('azerty', 'fghj', 1000),
    new Client('toto', 'tutu', 20000)];

  constructor() {
  }


  get clients(): Client[] {
    return this._clients;
  }

  public delete(index: number) {
    this.clients.splice(index, 1);
  }

  public add(client: Client) {
    this.clients.push(client);
  }
}
