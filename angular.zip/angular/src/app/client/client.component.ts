import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {Client} from '../model/client';

@Component({
  selector: 'app-client',
  templateUrl: './client.component.html',
  styleUrls: ['./client.component.css']
})
export class ClientComponent implements OnInit {

  private client: Client = new Client();
  @Output()
  private enregistrer: EventEmitter<Client> = new EventEmitter<Client>();

  constructor() {
  }

  ngOnInit() {
  }

  public save() {
    this.enregistrer.emit(this.client);
    this.client = new Client();
  }

}
