import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AscToolTipsComponent } from './asc-tool-tips.component';

describe('AscToolTipsComponent', () => {
  let component: AscToolTipsComponent;
  let fixture: ComponentFixture<AscToolTipsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AscToolTipsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AscToolTipsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
