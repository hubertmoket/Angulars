import {Component, HostListener, Input, OnInit} from '@angular/core';

@Component({
  selector: 'app-asc-tool-tips',
  templateUrl: './asc-tool-tips.component.html',
  styleUrls: ['./asc-tool-tips.component.css']
})
export class AscToolTipsComponent implements OnInit {

  @Input('asc-tooltip-titre')
  private titre: string;

  private visible = false;

  constructor() {
  }

  ngOnInit() {
  }

  @HostListener('mouseover')
  over() {
    this.visible = true;
  }

  @HostListener('mouseleave')
  leave() {
    this.visible = false;
  }
}
